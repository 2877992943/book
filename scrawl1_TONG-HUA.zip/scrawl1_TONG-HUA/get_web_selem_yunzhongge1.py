import json

import requests
from bs4 import BeautifulSoup
import re

from selenium.webdriver.chrome.options import Options
import time
#from webdriver_manager.chrome import ChromeDriverManager
###https://www.kanunu8.com/book5/bubujingxin/

def safariDriver():
    from selenium import webdriver

    # 设置Safari的选项
    safari_options = webdriver.safari.options.Options()

    # 创建Safari WebDriver实例
    driver = webdriver.Safari(options=safari_options)

    # 打开一个网页
    #driver.get(url)

    # 你的Selenium代码可以继续在这里...

    # 最后，关闭浏览器
    #driver.quit()
    return driver

driver=safariDriver()
mainlink='https://www.kanunu8.com/book5/yunzhongge1/'
alllink="""
 <li><a href="5609.html">序言</a></li>
<li><a href="5610.html">第一章 今夕何夕，见此邂逅</a></li>
<li><a href="5611.html">第二章 有匪君子，如圭如璧</a></li>
<li><a href="5612.html">第三章 人生自是有情痴</a></li>
<li><a href="5613.html">第四章 我心伤悲，莫知我哀</a></li>
<li><a href="5614.html">第五章 结交在相知</a></li>
<li><a href="5615.html">第六章 此情须问天</a></li>
<li><a href="5616.html">第七章 风乍起，吹皱一池春水</a></li>
<li><a href="5617.html">第八章 凄凉别后两应同</a></li>
<li><a href="5618.html">第九章 只愿君心似我心</a></li>
<li><a href="5619.html">第十章 人生只似风飘絮</a></li>
<li><a href="5620.html">第十一章 一寸相思千万绪</a></li>
<li><a href="5621.html">第十二章 清波月下歌</a></li>
<li><a href="5622.html">第十三章 纵使相逢应不识</a></li>
<li><a href="5623.html">第十四章 兵戈乍起，人心难测</a></li>
<li><a href="5624.html">第十五章 绾发结同心</a></li>
<li><a href="5625.html">第十六章 一片芳心冷若灰</a></li>
<li><a href="5626.html">第十七章 半随流水半随尘</a></li>
<li><a href="5627.html">第十八章 半随流水半随尘</a></li>
"""
jsonpath='./html_yunzhongge1.json'
# 正则表达式
#pattern = r'href="(/[^"]+)"'
pattern=r'href="(\d+\.html)"'
# 使用re.search查找匹配项
match = re.findall(pattern, alllink)
ll=[]
for elem in match:
    link=mainlink+elem
    ll.append(link)
print(ll)


url=ll[0]
rst=[]
wr=open(jsonpath,'w')
for url in ll:
    print(66,url)
    # 打开网页
    driver.get(url)
    time.sleep(4)
    # 获取网页源代码
    page_source = driver.page_source

    wr.write(json.dumps([page_source],ensure_ascii=False)+'\n')
    #break


    # 打印源代码
    print(page_source)
    time.sleep(6)
driver.quit()

#
# try:
#     # 等待弹出按钮出现，设置最长等待时间
#     popup_button = WebDriverWait(driver, 10).until(
#         EC.element_to_be_clickable((By.ID, 'popup_button_id'))  # 使用合适的定位器替换'popup_button_id'
#     )
#
#     # 点击弹出按钮
#     popup_button.click()
#
#     # 获取网页源代码
#     page_source = driver.page_source
#
#     # 打印源代码
#     print(page_source)
#
# finally:
#     # 关闭浏览器
#     driver.quit()



