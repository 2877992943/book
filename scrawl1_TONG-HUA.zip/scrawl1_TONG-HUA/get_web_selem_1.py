import json

import requests
from bs4 import BeautifulSoup
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

###https://www.kanunu8.com/book5/bubujingxin/




alllink="""
<div class="mulu-list">
    <ul>
<li><a href="5499.html">楔子</a></li>
<li><a href="5500.html">第一章</a></li>
<li><a href="5501.html">第二章</a></li>
<li><a href="5502.html">第三章</a></li>
<li><a href="5503.html">第四章</a></li>
<li><a href="5504.html">第五章</a></li>
<li><a href="5505.html">第六章</a></li>
<li><a href="5506.html">第七章</a></li>
<li><a href="5507.html">第八章</a></li>
<li><a href="5508.html">第九章</a></li>
<li><a href="5509.html">第十章</a></li>
<li><a href="5510.html">第十一章</a></li>
<li><a href="5511.html">第十二章</a></li>
<li><a href="5512.html">第十三章</a></li>
<li><a href="5513.html">第十四章</a></li>
<li><a href="5514.html">第十五章</a></li>
<li><a href="5515.html">第十六章</a></li>
<li><a href="5516.html">第十七章</a></li>
<li><a href="5517.html">第十八章</a></li>
<li><a href="5518.html">第十九章</a></li>
<li><a href="5519.html">第二十章</a></li>
<li><a href="5520.html">第二十一章</a></li>
<li><a href="5521.html">第二十二章</a></li>
<li><a href="5522.html">第二十三章</a></li>
<li><a href="5523.html">第二十四章</a></li>
<li><a href="5524.html">第二十五章</a></li>
<li><a href="5525.html">第二十六章</a></li>
<li><a href="5526.html">第二十七章</a></li>
<li><a href="5527.html">第二十八章</a></li>
<li><a href="5528.html">第二十九章</a></li>
<li><a href="5529.html">第三十章</a></li>
<li><a href="5530.html">第三十一章</a></li>
<li><a href="5531.html">第三十二章</a></li>
<li><a href="5532.html">第三十三章</a></li>
<li><a href="5533.html">第三十四章</a></li>
<li><a href="5534.html">第三十五章</a></li>
<li><a href="5535.html">第三十六章</a></li>
<li><a href="5536.html">第三十七章</a></li>
<li><a href="5537.html">第三十八章</a></li>
<li><a href="5538.html">第三十九章</a></li>
<li><a href="5539.html">第四十章</a></li>
<li><a href="5540.html">第四十一章</a></li>
<li><a href="5541.html">第四十二章</a></li>
<li><a href="5542.html">第四十三章</a></li>
<li><a href="5543.html">第四十四章</a></li>
<li><a href="5544.html">第四十五章</a></li>
<li><a href="5545.html">第四十六章</a></li>
<li><a href="5546.html">第四十七章</a></li>
<li><a href="5547.html">第四十八章</a></li>
<li><a href="5548.html">第四十九章</a></li>
<li><a href="5549.html">第五十章</a></li>
<li><a href="5550.html">第五十一章</a></li>
<li><a href="5551.html">第五十二章</a></li>
<li><a href="5552.html">第五十三章</a></li>
<li><a href="5553.html">第五十四章</a></li>
<li><a href="5554.html">第五十五章</a></li>
<li><a href="5555.html">第五十六章</a></li>

 	</ul>
	</div>
	<div class="mulu-list">
    <ul>
<li><a href="5557.html">第一章</a></li>
<li><a href="5558.html">第二章</a></li>
<li><a href="5559.html">第三章</a></li>
<li><a href="5560.html">第五章</a></li>
<li><a href="5561.html">第六章</a></li>
<li><a href="5562.html">第七章</a></li>
<li><a href="5563.html">第八章</a></li>
<li><a href="5564.html">第九章</a></li>
<li><a href="5565.html">第十章</a></li>
<li><a href="5566.html">第十一章</a></li>
<li><a href="5567.html">第十二章</a></li>
<li><a href="5568.html">第十三章</a></li>
<li><a href="5569.html">第十四章</a></li>
<li><a href="5570.html">第十五章</a></li>
<li><a href="5571.html">第十六章</a></li>
<li><a href="5572.html">第十七章</a></li>
<li><a href="5573.html">第十八章</a></li>
<li><a href="5574.html">第十九章</a></li>
<li><a href="5575.html">第二十章</a></li>
<li><a href="5576.html">第二十一章</a></li>
<li><a href="5577.html">第二十二章</a></li>
<li><a href="5578.html">后记</a></li>

 	</ul>
	</div>
"""

# 正则表达式
#pattern = r'href="(/[^"]+)"'
pattern=r'href="(\d+\.html)"'
# 使用re.search查找匹配项
match = re.findall(pattern, alllink)
ll=[]
for elem in match:
    link='https://www.kanunu8.com/book5/bubujingxin/'+elem
    ll.append(link)
print()

# 指定ChromeDriver的路径
chromedriver_path = 'path/to/chromedriver'

# 初始化webdriver
options = webdriver.ChromeOptions()
# 如果不希望浏览器界面出现，可以添加以下选项
#options.add_argument('--headless')

# 创建一个Chrome浏览器实例
driver = webdriver.Chrome(#executable_path=chromedriver_path,
                          options=options)
# 发送HTTP请求
url=ll[0]
rst=[]
wr=open('./html_bubujingxin.json','w')
for url in ll:
    # 打开网页
    driver.get(url)
    time.sleep(4)
    # 获取网页源代码
    page_source = driver.page_source

    wr.write(json.dumps([page_source],ensure_ascii=False)+'\n')
    #break


    # 打印源代码
    print(page_source)
    time.sleep(6)
driver.quit()

#
# try:
#     # 等待弹出按钮出现，设置最长等待时间
#     popup_button = WebDriverWait(driver, 10).until(
#         EC.element_to_be_clickable((By.ID, 'popup_button_id'))  # 使用合适的定位器替换'popup_button_id'
#     )
#
#     # 点击弹出按钮
#     popup_button.click()
#
#     # 获取网页源代码
#     page_source = driver.page_source
#
#     # 打印源代码
#     print(page_source)
#
# finally:
#     # 关闭浏览器
#     driver.quit()



