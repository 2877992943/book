import json

import requests
from bs4 import BeautifulSoup
import re

from selenium.webdriver.chrome.options import Options
import time
#from webdriver_manager.chrome import ChromeDriverManager
###https://www.kanunu8.com/book5/bubujingxin/

def safariDriver():
    from selenium import webdriver

    # 设置Safari的选项
    safari_options = webdriver.safari.options.Options()

    # 创建Safari WebDriver实例
    driver = webdriver.Safari(options=safari_options)

    # 打开一个网页
    #driver.get(url)

    # 你的Selenium代码可以继续在这里...

    # 最后，关闭浏览器
    #driver.quit()
    return driver

driver=safariDriver()
mainlink='https://www.kanunu8.com/book5/yunzhongge1/'
mainlink='https://www.kanunu8.com/book5/yunzhongge2/'
mainlink='https://www.kanunu8.com/book5/yunzhongge3/'
mainlink='https://www.kanunu8.com/book2/10875/'
alllink="""
<div class="catalog" style="height: auto !important;">
			<h1>散落星河的记忆</h1>
			<div class="info">作者：桐华</div>

<div class="summary" style="height: auto !important;"> 				<strong>内容简介：</strong>
<div class="intro">
<p>在基因决定生死的未来世界，寻找至死不渝的爱情——随着地球环境恶化、能源枯竭，人类不得不走向星际。生死存亡时刻，基因研究的大门被彻底打开，人类为了获取更强壮的体魄、更强大的力量、更多的生存机会，对自己的基因进行了改造。随着时间流逝，各种修改过的基因彼此交融，潜藏在基因内的问题渐渐浮现，人类才发现基因修改在增加生存机会的同时，也带来了一些毁灭性的问题。那些因为融合其他物种基因而获得异常力量的人群，被叫作“携带异种基因的人类”，遭受到越来越严重的排斥。尤其是那些外在体貌和人类有异的族群，被轻蔑地叫作“异种”。一个基因纯粹却没有记忆的女子和携带异种基因的男人相遇，他们的爱情能走多远？</p>
</div><div class="google-auto-placed" style="width: 100%; height: auto; clear: both; text-align: center;"><ins data-ad-format="auto" class="adsbygoogle adsbygoogle-noablate" data-ad-client="ca-pub-2995949807212160" data-adsbygoogle-status="done" style="display: block; margin: 10px auto; background-color: transparent; height: 280px;" data-ad-status="filled"><div id="aswift_1_host" style="border: none; height: 280px; width: 800px; margin: 0px; padding: 0px; position: relative; visibility: visible; background-color: transparent; display: inline-block; overflow: visible;"><iframe id="aswift_1" name="aswift_1" browsingtopics="true" style="left:0;position:absolute;top:0;border:0;width:800px;height:280px;" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" width="800" height="280" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" allow="attribution-reporting; run-ad-auction" src="https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-2995949807212160&amp;output=html&amp;h=280&amp;adk=1149590581&amp;adf=2548288913&amp;pi=t.aa~a.2291915000~rp.4&amp;w=800&amp;abgtt=6&amp;fwrn=4&amp;fwrnh=100&amp;lmt=1706535960&amp;rafmt=1&amp;to=qs&amp;pwprc=7017195960&amp;format=800x280&amp;url=https%3A%2F%2Fwww.kanunu8.com%2Fbook2%2F10875%2F&amp;fwr=0&amp;pra=3&amp;rpe=1&amp;resp_fmts=3&amp;wgl=1&amp;fa=40&amp;uach=WyJtYWNPUyIsIjE1LjAuMCIsImFybSIsIiIsIjEzMy4wLjY5NDMuNTUiLG51bGwsMCxudWxsLCI2NCIsW1siTm90KEE6QnJhbmQiLCI5OS4wLjAuMCJdLFsiR29vZ2xlIENocm9tZSIsIjEzMy4wLjY5NDMuNTUiXSxbIkNocm9taXVtIiwiMTMzLjAuNjk0My41NSJdXSwwXQ..&amp;dt=1739763159730&amp;bpp=1&amp;bdt=46&amp;idt=69&amp;shv=r20250211&amp;mjsv=m202502110101&amp;ptt=9&amp;saldr=aa&amp;abxe=1&amp;cookie=ID%3D02c6ad9389e0cf8c%3AT%3D1735810601%3ART%3D1739763094%3AS%3DALNI_Mb86vyz8-O5V3twZMjNeXY2njopSw&amp;gpic=UID%3D00000fd0f4357227%3AT%3D1735810601%3ART%3D1739763094%3AS%3DALNI_MaJZb8eEV2XE372oJ1shHE7NWOfLQ&amp;eo_id_str=ID%3Db56f36fbf7bb415b%3AT%3D1735810601%3ART%3D1739763094%3AS%3DAA-AfjbuSr31RirP8HgFtqfVdvos&amp;prev_fmts=0x0&amp;nras=2&amp;correlator=8334882785595&amp;frm=20&amp;pv=1&amp;u_tz=480&amp;u_his=1&amp;u_h=982&amp;u_w=1512&amp;u_ah=890&amp;u_aw=1512&amp;u_cd=30&amp;u_sd=2&amp;dmc=8&amp;adx=349&amp;ady=342&amp;biw=1497&amp;bih=738&amp;scr_x=0&amp;scr_y=0&amp;eid=95344790%2C95350549%2C95352068%2C95347433%2C95350016&amp;oid=2&amp;pvsid=4202193317593463&amp;tmod=861527330&amp;uas=0&amp;nvt=1&amp;ref=https%3A%2F%2Fwww.kanunu8.com%2Ffiles%2Fwriter%2F1415.html&amp;fc=1920&amp;brdim=0%2C0%2C0%2C0%2C1512%2C38%2C0%2C0%2C1512%2C738&amp;vis=2&amp;rsz=%7C%7Cs%7C&amp;abl=NS&amp;fu=128&amp;bc=31&amp;bz=0&amp;td=1&amp;tdf=2&amp;psd=W251bGwsbnVsbCxudWxsLDFd&amp;nt=1&amp;ifi=2&amp;uci=a!2&amp;fsb=1&amp;dtd=71" data-google-container-id="a!2" tabindex="0" title="Advertisement" aria-label="Advertisement" data-google-query-id="CJugsuniyYsDFe3tTAIdq-0eNQ" data-load-complete="true"></iframe></div></ins></div>
</div>
<div class="author"> 				 &nbsp;&nbsp;&nbsp;&nbsp;→  <a href="/files/writer/1415.html">桐华作品集</a> 			</div>
<div class="mulu-title">
<h2>第一卷：迷失</h2>
</div>
<div class="mulu-list">
<ul>
    <li><a href="5753.html">序章 1</a></li>
    <li><a href="5754.html">序章 2</a></li>
    <li><a href="5755.html">Chapter 1 异星婚礼 1</a></li>
    <li><a href="5756.html">Chapter 1 异星婚礼 2</a></li>
    <li><a href="5757.html">Chapter 1 异星婚礼 3</a></li>
    <li><a href="5758.html">Chapter 2 第一个朋友 1</a></li>
    <li><a href="5759.html">Chapter 2 第一个朋友 2</a></li>
    <li><a href="5760.html">Chapter 3 我到底是谁 1</a></li>
    <li><a href="5761.html">Chapter 3 我到底是谁 2</a></li>
    <li><a href="5762.html">Chapter 3 我到底是谁 3</a></li>
    <li><a href="5763.html">Chapter 3 我到底是谁 4</a></li>
    <li><a href="5764.html">Chapter 4 被遗弃的人 1</a></li>
    <li><a href="5765.html">Chapter 4 被遗弃的人 2</a></li>
    <li><a href="5766.html">Chapter 4 被遗弃的人 3</a></li>
    <li><a href="5767.html">Chapter 4 被遗弃的人 4</a></li>
    <li><a href="5768.html">Chapter 5 希望总是要有的 1</a></li>
    <li><a href="5769.html">Chapter 5 希望总是要有的 2</a></li>
    <li><a href="5770.html">Chapter 5 希望总是要有的 3</a></li>
    <li><a href="5771.html">Chapter 5 希望总是要有的 4</a></li>
    <li><a href="5772.html">Chapter 6 选择 1</a></li>
    <li><a href="5773.html">Chapter 6 选择 2</a></li>
    <li><a href="5774.html">Chapter 6 选择 3</a></li>
    <li><a href="5775.html">Chapter 7 意外刺杀 1</a></li>
    <li><a href="5776.html">Chapter 7 意外刺杀 3</a></li>
    <li><a href="5777.html">Chapter 7 意外刺杀 4</a></li>
    <li><a href="5778.html">Chapter 8 生活总有变数 1</a></li>
    <li><a href="5779.html">Chapter 8 生活总有变数 2</a></li>
    <li><a href="5780.html">Chapter 8 生活总有变数 3</a></li>
    <li><a href="5781.html">Chapter 8 生活总有变数 4</a></li>
    <li><a href="5782.html">Chapter 8 生活总有变数 5</a></li>
    <li><a href="5783.html">Chapter 9 这就是我 1</a></li>
    <li><a href="5784.html">Chapter 9 这就是我 2</a></li>
    <li><a href="5785.html">Chapter 9 这就是我 3</a></li>
    <li><a href="5786.html">Chapter 9 这就是我 4</a></li>
    <li><a href="5787.html">Chapter 9 这就是我 5</a></li>
    <li><a href="5788.html">Chapter 10 有我在，不要怕 1</a></li>
    <li><a href="5789.html">Chapter 10 有我在，不要怕 2</a></li>
    <li><a href="5790.html">Chapter 10 有我在，不要怕 3</a></li>
    <li><a href="5791.html">Chapter 10 有我在，不要怕 4</a></li>
    <li><a href="5792.html">Chapter 10 有我在，不要怕 5</a></li>
    <li><a href="5793.html">Chapter 11 在一起就好 1</a></li>
    <li><a href="5794.html">Chapter 11 在一起就好 2</a></li>
    <li><a href="5795.html">Chapter 11 在一起就好 3</a></li>
    <li><a href="5796.html">Chapter 11 在一起就好 4</a></li>
    <li><a href="5797.html">Chapter 11 在一起就好 5</a></li>
    <li><a href="5798.html">Chapter 12 我想我很爱你 1</a></li>
    <li><a href="5799.html">Chapter 12 我想我很爱你 2</a></li>
    <li><a href="5800.html">Chapter 12 我想我很爱你 3</a></li>
    <li><a href="5801.html">Chapter 12 我想我很爱你 4</a></li>
    <li><a href="5802.html">Chapter 12 我想我很爱你 5</a></li>
    <li><a href="5803.html">Chapter 12 我想我很爱你 6</a></li>
    <li><a href="5804.html">Chapter 13 从天堂到地狱 1</a></li>
    <li><a href="5805.html">Chapter 13 从天堂到地狱 2</a></li>
    <li><a href="5806.html">Chapter 13 从天堂到地狱 3</a></li>
    <li><a href="5807.html">Chapter 13 从天堂到地狱 4</a></li>
    <li><a href="5808.html">Chapter 13 从天堂到地狱 5</a></li>
    <li><a href="5809.html">Chapter 14 为你活下去 1</a></li>
    <li><a href="5810.html">Chapter 14 为你活下去 2</a></li>
    <li><a href="5811.html">Chapter 14 为你活下去 3</a></li>
    <li><a href="5812.html">Chapter 14 为你活下去 4</a></li>
    <li><a href="5813.html">Chapter 15 我们离婚吧 1</a></li>
    <li><a href="5814.html">Chapter 15 我们离婚吧 2</a></li>
    <li><a href="5815.html">Chapter 15 我们离婚吧 3</a></li>
    <li><a href="5816.html">Chapter 16 心动的感觉 1</a></li>
    <li><a href="5817.html">Chapter 16 心动的感觉 2</a></li>
    <li><a href="5818.html">Chapter 16 心动的感觉 3</a></li>
    <li><a href="5819.html">Chapter 17 久别重逢 1</a></li>
    <li><a href="5820.html">Chapter 17 久别重逢 2</a></li>
    <li><a href="5821.html">Chapter 17 久别重逢 3</a></li>
    <li><a href="5822.html">Chapter 18 每个人都有秘密 1</a></li>
    <li><a href="5823.html">Chapter 18 每个人都有秘密 2</a></li>
    <li><a href="5824.html">Chapter 18 每个人都有秘密 3</a></li>
    <li><a href="5825.html">Chapter 19 绝地复仇 1</a></li>
    <li><a href="5826.html">Chapter 19 绝地复仇 2</a></li>
</ul>
</div><div class="google-auto-placed" style="width: 100%; height: auto; clear: both; text-align: center;"><ins data-ad-format="auto" class="adsbygoogle adsbygoogle-noablate" data-ad-client="ca-pub-2995949807212160" data-adsbygoogle-status="done" style="display: block; margin: 10px auto; background-color: transparent; height: 0px;" data-ad-status="unfilled"><div id="aswift_2_host" style="border: none; height: 0px; width: 800px; margin: 0px; padding: 0px; position: relative; visibility: visible; background-color: transparent; display: inline-block; overflow: hidden; opacity: 0;"><iframe id="aswift_2" name="aswift_2" browsingtopics="true" style="left: 0px; position: absolute; top: 0px; border: 0px; width: 800px; height: 0px;" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" width="800" height="0" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" allow="attribution-reporting; run-ad-auction" src="https://googleads.g.doubleclick.net/pagead/ads?gdpr=0&amp;client=ca-pub-2995949807212160&amp;output=html&amp;h=280&amp;adk=2540751649&amp;adf=2883602954&amp;pi=t.aa~a.196389084~rp.4&amp;w=800&amp;abgtt=6&amp;fwrn=4&amp;fwrnh=100&amp;lmt=1706535960&amp;rafmt=1&amp;to=qs&amp;pwprc=7017195960&amp;format=800x280&amp;url=https%3A%2F%2Fwww.kanunu8.com%2Fbook2%2F10875%2F&amp;fwr=0&amp;pra=3&amp;rpe=1&amp;resp_fmts=3&amp;wgl=1&amp;fa=40&amp;uach=WyJtYWNPUyIsIjE1LjAuMCIsImFybSIsIiIsIjEzMy4wLjY5NDMuNTUiLG51bGwsMCxudWxsLCI2NCIsW1siTm90KEE6QnJhbmQiLCI5OS4wLjAuMCJdLFsiR29vZ2xlIENocm9tZSIsIjEzMy4wLjY5NDMuNTUiXSxbIkNocm9taXVtIiwiMTMzLjAuNjk0My41NSJdXSwwXQ..&amp;dt=1739763161208&amp;bpp=1&amp;bdt=1523&amp;idt=1&amp;shv=r20250211&amp;mjsv=m202502110101&amp;ptt=9&amp;saldr=aa&amp;abxe=1&amp;cookie=ID%3D02c6ad9389e0cf8c%3AT%3D1735810601%3ART%3D1739763094%3AS%3DALNI_Mb86vyz8-O5V3twZMjNeXY2njopSw&amp;gpic=UID%3D00000fd0f4357227%3AT%3D1735810601%3ART%3D1739763094%3AS%3DALNI_MaJZb8eEV2XE372oJ1shHE7NWOfLQ&amp;eo_id_str=ID%3Db56f36fbf7bb415b%3AT%3D1735810601%3ART%3D1739763094%3AS%3DAA-AfjbuSr31RirP8HgFtqfVdvos&amp;prev_fmts=0x0%2C800x280%2C1497x738&amp;nras=4&amp;correlator=8334882785595&amp;frm=20&amp;pv=1&amp;u_tz=480&amp;u_his=1&amp;u_h=982&amp;u_w=1512&amp;u_ah=890&amp;u_aw=1512&amp;u_cd=30&amp;u_sd=2&amp;dmc=8&amp;adx=349&amp;ady=1516&amp;biw=1497&amp;bih=738&amp;scr_x=0&amp;scr_y=0&amp;eid=95344790%2C95350549%2C95352068%2C95347433%2C95350016&amp;oid=2&amp;psts=AOrYGsmuBR3VoMw7qF9O3kjByz07GlBHB5LPqwhDlZ7j2ed2MGftlAKhCptIAwqlzs6MLEsMI6lDVxCv6qTCeW_zbv-ohEs_&amp;pvsid=4202193317593463&amp;tmod=861527330&amp;uas=0&amp;nvt=1&amp;ref=https%3A%2F%2Fwww.kanunu8.com%2Ffiles%2Fwriter%2F1415.html&amp;fc=1920&amp;brdim=0%2C0%2C0%2C0%2C1512%2C38%2C0%2C0%2C1512%2C738&amp;vis=1&amp;rsz=%7C%7Cs%7C&amp;abl=NS&amp;fu=128&amp;bc=31&amp;bz=0&amp;td=1&amp;tdf=2&amp;psd=W251bGwsbnVsbCxudWxsLDFd&amp;nt=1&amp;ifi=3&amp;uci=a!3&amp;btvi=1&amp;fsb=1&amp;dtd=11943" data-google-container-id="a!3" tabindex="0" title="Advertisement" aria-label="Advertisement" data-google-query-id="CN3wxO_iyYsDFcQmewcdcgcmJQ" data-load-complete="true"></iframe></div></ins></div>
<div class="mulu-title">
<h2>第二卷：窃梦</h2>
</div>
<div class="mulu-list">
<ul>
    <li><a href="5828.html">Chapter 1 今夕何夕 1</a></li>
    <li><a href="5829.html">Chapter 1 今夕何夕 2</a></li>
    <li><a href="5830.html">Chapter 1 今夕何夕 3</a></li>
    <li><a href="5831.html">Chapter 1 今夕何夕 4</a></li>
    <li><a href="5832.html">Chapter 2 梦碎 1</a></li>
    <li><a href="5833.html">Chapter 2 梦碎 2</a></li>
    <li><a href="5834.html">Chapter 2 梦碎 3</a></li>
    <li><a href="5835.html">Chapter 3 风从哪里来 1</a></li>
    <li><a href="5836.html">Chapter 3 风从哪里来 2</a></li>
    <li><a href="5837.html">Chapter 3 风从哪里来 3</a></li>
    <li><a href="5838.html">Chapter 4 谎言之上 1</a></li>
    <li><a href="5839.html">Chapter 4 谎言之上 2</a></li>
    <li><a href="5840.html">Chapter 4 谎言之上 3</a></li>
    <li><a href="5841.html">Chapter 4 谎言之上 4</a></li>
    <li><a href="5842.html">Chapter 4 谎言之上 5</a></li>
    <li><a href="5843.html">Chapter 4 谎言之上 6</a></li>
    <li><a href="5844.html">Chapter 4 谎言之上 7</a></li>
    <li><a href="5845.html">Chapter 5 光明与阴暗 1</a></li>
    <li><a href="5846.html">Chapter 5 光明与阴暗 2</a></li>
    <li><a href="5847.html">Chapter 5 光明与阴暗 3</a></li>
    <li><a href="5848.html">Chapter 5 光明与阴暗 4</a></li>
    <li><a href="5849.html">Chapter 5 光明与阴暗 5</a></li>
    <li><a href="5850.html">Chapter 5 光明与阴暗 6</a></li>
    <li><a href="5851.html">Chapter 5 光明与阴暗 7</a></li>
    <li><a href="5852.html">Chapter 6 迷思 1</a></li>
    <li><a href="5853.html">Chapter 6 迷思 2</a></li>
    <li><a href="5854.html">Chapter 6 迷思 3</a></li>
    <li><a href="5855.html">Chapter 6 迷思 4</a></li>
    <li><a href="5856.html">Chapter 6 迷思 5</a></li>
    <li><a href="5857.html">Chapter 6 迷思 6</a></li>
    <li><a href="5858.html">Chapter 6 迷思 7</a></li>
    <li><a href="5859.html">Chapter 7 龙之心 1</a></li>
    <li><a href="5860.html">Chapter 7 龙之心 2</a></li>
    <li><a href="5861.html">Chapter 7 龙之心 3</a></li>
    <li><a href="5862.html">Chapter 7 龙之心 4</a></li>
    <li><a href="5863.html">Chapter 8 情深1</a></li>
    <li><a href="5864.html">Chapter 8 情深2</a></li>
    <li><a href="5865.html">Chapter 8 情深3</a></li>
    <li><a href="5866.html">Chapter 8 情深4</a></li>
    <li><a href="5867.html">Chapter 8 情深5</a></li>
    <li><a href="5868.html">Chapter 8 情深6</a></li>
    <li><a href="5869.html">Chapter 9 知道你在 1</a></li>
    <li><a href="5870.html">Chaoter 9 知道你在 2</a></li>
    <li><a href="5871.html">Chapter 9 知道你在 3</a></li>
    <li><a href="5872.html">Chapter 9 知道你在 4</a></li>
    <li><a href="5873.html">Chapter 9 知道你在 5</a></li>
    <li><a href="5874.html">Chapter 9 知道你在 6</a></li>
    <li><a href="5875.html">Chapter 10 困局 1</a></li>
    <li><a href="5876.html">Chapter 10 困局 2</a></li>
    <li><a href="5877.html">Chapter 10 困局 3</a></li>
    <li><a href="5878.html">Chapter 10 困局 4</a></li>
    <li><a href="5879.html">Chapter 10 困局 5</a></li>
    <li><a href="5880.html">Chapter 11 无畏前行 1</a></li>
    <li><a href="5881.html">Chapter 11 无畏前行 2</a></li>
    <li><a href="5882.html">Chapter 11 无畏前行 3</a></li>
    <li><a href="5883.html">Chapter 11 无畏前行 4</a></li>
    <li><a href="5884.html">Chapter 11 无畏前行 5</a></li>
    <li><a href="5885.html">Chapter 11 无畏前行 6</a></li>
    <li><a href="5886.html">Chapter 11 无畏前行 7</a></li>
    <li><a href="5887.html">Chapter 11 无畏前行 8</a></li>
    <li><a href="5888.html">Chapter 12 我陪你 1</a></li>
    <li><a href="5889.html">Chapter 12 我陪你 2</a></li>
    <li><a href="5890.html">Chapter 12 我陪你 3</a></li>
    <li><a href="5891.html">Chapter 12 我陪你 4</a></li>
    <li><a href="5892.html">Chapter 12 我陪你 5</a></li>
    <li><a href="5893.html">Chapter 12 我陪你 6</a></li>
    <li><a href="5894.html">Chapter 13 誓言 1</a></li>
    <li><a href="5895.html">Chapter 13 誓言 2</a></li>
    <li><a href="5896.html">Chapter 13 誓言 3</a></li>
    <li><a href="5897.html">Chapter 13 誓言 4</a></li>
    <li><a href="5898.html">Chapter 14 异变 1</a></li>
    <li><a href="5899.html">Chapter 14 异变 2</a></li>
    <li><a href="5900.html">Chapter 14 异变 3</a></li>
    <li><a href="5901.html">Chapter 14 异变 4</a></li>
    <li><a href="5902.html">Chapter 14 异变 5</a></li>
    <li><a href="5903.html">Chapter 14 异变 6</a></li>
    <li><a href="5904.html">Chapter 15 哀与伤 1</a></li>
    <li><a href="5905.html">Chapter 15 哀与伤 2</a></li>
    <li><a href="5906.html">Chapter 15 哀与伤 3</a></li>
    <li><a href="5907.html">Chapter 15 哀与伤 4</a></li>
    <li><a href="5908.html">Chapter 15 哀与伤 5</a></li>
    <li><a href="5909.html">Chapter 16 祸福难料 1</a></li>
    <li><a href="5910.html">Chapter 16 祸福难料 2</a></li>
    <li><a href="5911.html">Chapter 16 祸福难料 3</a></li>
    <li><a href="5912.html">Chapter 16 祸福难料 4</a></li>
    <li><a href="5913.html">Chapter 16 祸福难料 5</a></li>
    <li><a href="5914.html">Chapter 16 祸福难料 6</a></li>
    <li><a href="5915.html">Chapter 17 宣战 1</a></li>
    <li><a href="5916.html">Chapter 17 宣战 2</a></li>
    <li><a href="5917.html">Chapter 17 宣战 3</a></li>
    <li><a href="5918.html">Chapter 17 宣战 4</a></li>
    <li><a href="5919.html">Chapter 17 宣战 5</a></li>
    <li><a href="5920.html">Chapter 18 光芒 1</a></li>
    <li><a href="5921.html">Chapter 18 光芒 2</a></li>
    <li><a href="5922.html">Chapter 18 光芒 3</a></li>
    <li><a href="5923.html">Chapter 18 光芒 4</a></li>
    <li><a href="5924.html">Chapter 19 幸好相逢 1</a></li>
    <li><a href="5925.html">Chapter 19 幸好相逢 2</a></li>
    <li><a href="5926.html">Chapter 19 幸好相逢 3</a></li>
    <li><a href="5927.html">Chapter 19 幸好相逢 4</a></li>
</ul>
</div>
<div class="mulu-title">
<h2>第三卷：化蝶</h2>
</div>
<div class="mulu-list">
<ul>
    <li><a href="5929.html">Chapter 1 刹那永恒 1</a></li>
    <li><a href="5930.html">Chapter 1 刹那永恒 2</a></li>
    <li><a href="5931.html">Chapter 1 刹那永恒 3</a></li>
    <li><a href="5932.html">Chapter 1 刹那永恒 4</a></li>
    <li><a href="5933.html">Chapter 1 刹那永恒 5</a></li>
    <li><a href="5934.html">Chapter 1 刹那永恒 6</a></li>
    <li><a href="5935.html">Chapter 2 光明与黑暗 1</a></li>
    <li><a href="5936.html">Chapter 2 光明与黑暗 2</a></li>
    <li><a href="5937.html">Chapter 2 光明与黑暗 3</a></li>
    <li><a href="5938.html">Chapter 2 光明与黑暗 4</a></li>
    <li><a href="5939.html">Chapter 3 这就是战争 1</a></li>
    <li><a href="5940.html">Chapter 3 这就是战争 2</a></li>
    <li><a href="5941.html">Chapter 3 这就是战争 3</a></li>
    <li><a href="5942.html">Chapter 3 这就是战争 4</a></li>
    <li><a href="5943.html">Chapter 3 这就是战争 5</a></li>
    <li><a href="5944.html">Chapter 3 这就是战争 6</a></li>
    <li><a href="5945.html">Chapter 4 归于尘土 1</a></li>
    <li><a href="5946.html">Chapter 4 归于尘土 2</a></li>
    <li><a href="5947.html">Chapter 4 归于尘土 3</a></li>
    <li><a href="5948.html">Chapter 4 归于尘土 4</a></li>
    <li><a href="5949.html">Chapter 4 归于尘土 5</a></li>
    <li><a href="5950.html">Chapter 4 归于尘土 6</a></li>
    <li><a href="5951.html">Chapter 5 最希望你记住 1</a></li>
    <li><a href="5952.html">Chapter 5 最希望你记住 2</a></li>
    <li><a href="5953.html">Chapter 5 最希望你记住 3</a></li>
    <li><a href="5954.html">Chapter 5 最希望你记住 4</a></li>
    <li><a href="5955.html">Chapter 6 棋子 1</a></li>
    <li><a href="5956.html">Chapter 6 棋子 2</a></li>
    <li><a href="5957.html">Chapter 6 棋子 3</a></li>
    <li><a href="5958.html">Chapter 6 棋子 4</a></li>
    <li><a href="5959.html">Chapter 6 棋子 5</a></li>
    <li><a href="5960.html">Chapter 7 剧变</a></li>
    <li><a href="5961.html">Chapter 8 独自等待 1</a></li>
    <li><a href="5962.html">Chapter 8 独自等待 2</a></li>
    <li><a href="5963.html">Chapter 9 小角 1</a></li>
    <li><a href="5964.html">Chapter 9 小角 2</a></li>
    <li><a href="5965.html">Chapter 9 小角 3</a></li>
    <li><a href="5966.html">Chapter 10 秘密 1</a></li>
    <li><a href="5967.html">Chapter 10 秘密 2</a></li>
    <li><a href="5968.html">Chapter 10 秘密 3</a></li>
    <li><a href="5969.html">Chapter 10 秘密 4</a></li>
    <li><a href="5970.html">Chapter 10 秘密 5</a></li>
    <li><a href="5971.html">Chapter 11 逝去的过往 1</a></li>
    <li><a href="5972.html">Chapter 11 逝去的过往 2</a></li>
    <li><a href="5973.html">Chapter 12 欢迎来到普通异种的世界 1</a></li>
    <li><a href="5974.html">Chapter 12 欢迎来到普通异种的世界 2</a></li>
    <li><a href="5975.html">Chapter 12 欢迎来到普通异种的世界 3</a></li>
    <li><a href="5976.html">Chapter 13 死里逃生 1</a></li>
    <li><a href="5977.html">Chapter 13 死里逃生 2</a></li>
    <li><a href="5978.html">Chapter 13 死里逃生 3</a></li>
    <li><a href="5979.html">Chapter 13 死里逃生 4</a></li>
    <li><a href="5980.html">Chapter 14 万丈红尘 1</a></li>
    <li><a href="5981.html">Chapter 14 万丈红尘 2</a></li>
    <li><a href="5982.html">Chapter 14 万丈红尘 3</a></li>
    <li><a href="5983.html">Chapter 14 万丈红尘 4</a></li>
    <li><a href="5984.html">Chapter 15 时间的尽头 1</a></li>
    <li><a href="5985.html">Chapter 15 时间的尽头 2</a></li>
    <li><a href="5986.html">Chapter 15 时间的尽头 3</a></li>
    <li><a href="5987.html">Chapter 16 如果你还活着 1</a></li>
    <li><a href="5988.html">Chapter 16 如果你还活着 2</a></li>
    <li><a href="5989.html">Chapter 16 如果你还活着 3</a></li>
    <li><a href="5990.html">Chapter 16 如果你还活着 4</a></li>
    <li><a href="5991.html">Chapter 17 归来 1</a></li>
    <li><a href="5992.html">Chapter 17 归来 2</a></li>
    <li><a href="5993.html">Chapter 17 归来 3</a></li>
    <li><a href="5994.html">Chapter 17 归来 4</a></li>
    <li><a href="5995.html">Chapter 18 最好的时光 1</a></li>
    <li><a href="5996.html">Chapter 18 最好的时光 2</a></li>
    <li><a href="5997.html">Chapter 18 最好的时光 3</a></li>
    <li><a href="5998.html">Chapter 18 最好的时光 4</a></li>
    <li><a href="5999.html">Chapter 18 最好的时光 5</a></li>
    <li><a href="6000.html">Chapter 19 新希望 1</a></li>
    <li><a href="6001.html">Chapter 19 新希望 2</a></li>
    <li><a href="6002.html">Chapter 19 新希望 3</a></li>
</ul>
</div>
<div class="mulu-title">
<h2>第四卷：璀璨</h2>
</div>
<div class="mulu-list">
<ul>
    <li><a href="6004.html">Chapter 1 命运的选择 1</a></li>
    <li><a href="6005.html">Chapter 1 命运的选择 2</a></li>
    <li><a href="6006.html">Chapter 1 命运的选择 3</a></li>
    <li><a href="6007.html">Chapter 2 褪色的记忆 1</a></li>
    <li><a href="6008.html">Chapter 2 褪色的记忆 2</a></li>
    <li><a href="6009.html">Chapter 2 褪色的记忆 3</a></li>
    <li><a href="6010.html">Chapter 3 为你而战 1</a></li>
    <li><a href="6011.html">Chapter 3 为你而战 2</a></li>
    <li><a href="6012.html">Chapter 3 为你而战 3</a></li>
    <li><a href="6013.html">Chapter 4 身不由己 1</a></li>
    <li><a href="6014.html">Chapter 4 身不由己 2</a></li>
    <li><a href="6015.html">Chapter 4 身不由己 3</a></li>
    <li><a href="6016.html">Chapter 5 并肩作战 1</a></li>
    <li><a href="6017.html">Chapter 5 并肩作战 2</a></li>
    <li><a href="6018.html">Chapter 5 并肩作战 3</a></li>
    <li><a href="6019.html">Chapter 5 并肩作战 4</a></li>
    <li><a href="6020.html">Chapter 5 并肩作战 5</a></li>
    <li><a href="6021.html">Chapter 6 圆舞 1</a></li>
    <li><a href="6022.html">Chapter 6 圆舞 2</a></li>
    <li><a href="6023.html">Chapter 7 小角爱洛洛 1</a></li>
    <li><a href="6024.html">Chapter 7 小角爱洛洛 2</a></li>
    <li><a href="6025.html">Chapter 8 一个人的战斗 1</a></li>
    <li><a href="6026.html">Chapter 8 一个人的战斗 2</a></li>
    <li><a href="6027.html">Chapter 8 一个人的战斗 3</a></li>
    <li><a href="6028.html">Chapter 9 送别 1</a></li>
    <li><a href="6029.html">Chapter 9 送别 2</a></li>
    <li><a href="6030.html">Chapter 10 善恶同体 1</a></li>
    <li><a href="6031.html">Chapter 10 善恶同体 2</a></li>
    <li><a href="6032.html">Chapter 10 善恶同体 3</a></li>
    <li><a href="6033.html">Chapter 11 玫瑰的刺 1</a></li>
    <li><a href="6034.html">Chapter 11 玫瑰的刺 2</a></li>
    <li><a href="6035.html">Chapter 11 玫瑰的刺 3</a></li>
    <li><a href="6036.html">Chapter 11 玫瑰的刺 4</a></li>
    <li><a href="6037.html">Chapter 12 正面相见 1</a></li>
    <li><a href="6038.html">Chapter 12 正面相见 2</a></li>
    <li><a href="6039.html">Chapter 12 正面相见 3</a></li>
    <li><a href="6040.html">Chapter 12 正面相见 4</a></li>
    <li><a href="6041.html">Chapter 13 夕颜朝颜 1</a></li>
    <li><a href="6042.html">Chapter 13 夕颜朝颜 2</a></li>
    <li><a href="6043.html">Chapter 13 夕颜朝颜 3</a></li>
    <li><a href="6044.html">Chapter 13 夕颜朝颜 4</a></li>
    <li><a href="6045.html">Chapter 14 生命之歌 1</a></li>
    <li><a href="6046.html">Chapter 14 生命之歌 2</a></li>
    <li><a href="6047.html">Chapter 14 生命之歌 3</a></li>
    <li><a href="6048.html">Chapter 15 洛洛爱小角 1</a></li>
    <li><a href="6049.html">Chapter 15 洛洛爱小角 2</a></li>
    <li><a href="6050.html">Chapter 16 不是演戏 1</a></li>
    <li><a href="6051.html">Chapter 16 不是演戏 2</a></li>
    <li><a href="6052.html">Chapter 17 恢复记忆 1</a></li>
    <li><a href="6053.html">Chapter 17 恢复记忆 2</a></li>
    <li><a href="6054.html">Chapter 17 恢复记忆 3</a></li>
    <li><a href="6055.html">Chapter 17 恢复记忆 4</a></li>
    <li><a href="6056.html">Chapter 18 岁月如歌 1</a></li>
    <li><a href="6057.html">Chapter 18 岁月如歌 2</a></li>
    <li><a href="6058.html">Chapter 18 岁月如歌 3</a></li>
    <li><a href="6059.html">Chapter 18 岁月如歌 4</a></li>
    <li><a href="6060.html">Chapter 19 誓言犹在 1</a></li>
    <li><a href="6061.html">Chapter 19 誓言犹在 2</a></li>
    <li><a href="6062.html">Chapter 19 誓言犹在 3</a></li>
    <li><a href="6063.html">Chapter 20 最高明的谎言 1</a></li>
    <li><a href="6064.html">Chapter 20 最高明的谎言 2</a></li>
    <li><a href="6065.html">Chapter 21 世界的秩序 1</a></li>
    <li><a href="6066.html">Chapter 21 世界的秩序 2</a></li>
    <li><a href="6067.html">Chapter 21 世界的秩序 3</a></li>
    <li><a href="6068.html">Chapter 21 世界的秩序 4</a></li>
    <li><a href="6069.html">Chapter 21 世界的秩序 5</a></li>
    <li><a href="6070.html">Chapter 22 新希望 1</a></li>
    <li><a href="6071.html">Chapter 22 新希望 2</a></li>
    <li><a href="6072.html">Chapter 22 新希望 3</a></li>
    <li><a href="6073.html">Chapter 22 新希望 4</a></li>
    <li><a href="6074.html">Chapter 22 新希望 5</a></li>
    <li><a href="6075.html">Chapter 23 星河璀璨 1</a></li>
    <li><a href="6076.html">Chapter 23 星河璀璨 2</a></li>
    <li><a href="6077.html">Chapter 23 星河璀璨 3</a></li>
    <li><a href="6078.html">Chapter 23 星河璀璨 4</a></li>
    <li><a href="6079.html">Chapter 23 星河璀璨 5</a></li>
    <li><a href="6080.html">番外：朝夕 1</a></li>
    <li><a href="6081.html">番外：朝夕 2</a></li>
    <li><a href="6082.html">番外：我愿意 1</a></li>
    <li><a href="6083.html">番外：我愿意 2</a></li>
</ul>
</div>


<div class="mulu-title"><h2 class="">看过此书的人还喜欢</h2></div>
<div class="common-list1 common-list2">
<a href="/book2/10914/"><b>1</b>《知否？知否？应是绿肥红瘦》<span class="common-ver-line">作者：关心则乱</span></a>
<a href="/book2/11024/"><b>2</b>《很想很想你》<span class="common-ver-line">作者：墨宝非宝</span></a>
<a href="/book5/shunvgonglue/"><b>4</b>《庶女攻略(锦心似玉)》<span class="common-ver-line">作者：吱吱</span></a>
<a href="/book5/fanhua/"><b>2</b>《繁花》<span class="common-ver-line">作者：金宇澄</span></a>
<a href="/book5/nishiwoderongyao/"><b>2</b>《你是我的荣耀》<span class="common-ver-line">作者：顾漫</span></a>

<a class="load-more" href="/genres.html">查看图书全部分类</a>
	</div>
	</div>
"""
jsonpath='./html_sanLuoXingHeDeJiyi.json'
# 正则表达式
#pattern = r'href="(/[^"]+)"'
pattern=r'href="(\d+\.html)"'
# 使用re.search查找匹配项
match = re.findall(pattern, alllink)
ll=[]
for elem in match:
    link=mainlink+elem
    ll.append(link)
print(ll)


url=ll[0]
rst=[]
wr=open(jsonpath,'w')
for url in ll:
    print(66,url)
    # 打开网页
    driver.get(url)
    time.sleep(4)
    # 获取网页源代码
    page_source = driver.page_source

    wr.write(json.dumps([page_source],ensure_ascii=False)+'\n')
    #break


    # 打印源代码
    print(page_source)
    time.sleep(6)
driver.quit()

#
# try:
#     # 等待弹出按钮出现，设置最长等待时间
#     popup_button = WebDriverWait(driver, 10).until(
#         EC.element_to_be_clickable((By.ID, 'popup_button_id'))  # 使用合适的定位器替换'popup_button_id'
#     )
#
#     # 点击弹出按钮
#     popup_button.click()
#
#     # 获取网页源代码
#     page_source = driver.page_source
#
#     # 打印源代码
#     print(page_source)
#
# finally:
#     # 关闭浏览器
#     driver.quit()



