import json
import os

import requests
from bs4 import BeautifulSoup
import re


pattern=r'<p style="height: auto !important;">(.*?)</p>'

# 定义一个函数来检查 <p> 标签的 style 属性是否符合条件
def has_specific_style(tag):
    #return tag.name == 'p' and tag.has_attr('style') and 'height: auto !important' in tag['style']
    return tag.name=='p'

def is_headd(tag):
    return tag.name=='h1'


# f=open('html_damoyao2.json')
# f=open('html_bubujingxin.json')
# f=open('html_yunzhongge1.json')
# f=open('html_yunzhongge2.json')
# f=open('html_yunzhongge3.json')
# f=open('html_sanLuoXingHeDeJiyi.json')

# filename1='sanLuoXingHeDeJiyi'


def main(filename1,jsonpath):
    f=open(jsonpath)
    cnt = 0
    os.makedirs(filename1)
    for line in f.readlines():
        line=line.strip()
        if line:
            l=json.loads(line)[0]
            print(l)
            soup=BeautifulSoup(l, 'html.parser')
            # 使用 find_all 方法找到所有符合条件的 <p> 标签
            matching_paragraphs = soup.find_all(has_specific_style)
            head1=soup.find_all(is_headd)
            head=head1[0].text
            text=head+'\n'
            # 打印找到的 <p> 标签
            ts=[]
            for p in matching_paragraphs:
                print(p)
                ts.append(p.text)
            ###
            text+='\n'.join(ts)
            #
            wr=open(f'./{filename1}/{cnt}.txt','w')
            wr.write(text)
            wr.close()
            cnt+=1

jsonpath1='./html_NapianXingKong.json'
jsonpath2='./html_banNuanShiGuang.json'
jsonpath3='./html_zuimeishiguang.json'
jsonpath4='./html_huiBuquNianshaoShiguang.json'
jsonpath5='./html_huiBuquNianshaoShiguang2.json'
main('NapianXingKong',jsonpath1)
main('banNuanShiGuang',jsonpath2)
main('zuimeishiguang',jsonpath3)
main('huiBuquNianshaoShiguang',jsonpath4)
main('huiBuquNianshaoShiguang2',jsonpath5)

