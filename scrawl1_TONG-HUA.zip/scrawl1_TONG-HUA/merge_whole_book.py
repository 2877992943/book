import os

maindir='banNuanShiGuang'


allbook=[]
for fn in os.listdir(maindir):
    fn1=maindir+'/'+fn
    open()
