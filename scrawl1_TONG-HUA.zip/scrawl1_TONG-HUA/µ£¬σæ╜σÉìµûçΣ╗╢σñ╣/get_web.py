

import requests
from bs4 import BeautifulSoup
import re

alllink="""
<dl id="dir" style="height: auto;"><dd><a href="/book/6438/2635.htm">第一章 绑架</a></dd><dd><a href="/book/6438/2636.htm">第二章 情愫</a></dd><dd><a href="/book/6438/2637.htm">第三章 鸽魂</a></dd><dd><a href="/book/6438/2638.htm">第四章 失身</a></dd><dd><a href="/book/6438/2639.htm">第五章 初吻</a></dd><dd><a href="/book/6438/2640.htm">第六章 逃命</a></dd><dd><a href="/book/6438/2641.htm">第七章 蹴鞠</a></dd><dd><a href="/book/6438/2642.htm">第八章 灿笑</a></dd><dd><a href="/book/6438/2643.htm">第九章 情乱</a></dd><dd><a href="/book/6438/2644.htm">第十章 怒吻</a></dd><dd><a href="/book/6438/2645.htm">第十一章 吵架</a></dd><dd><a href="/book/6438/2646.htm">第十二章 生病</a></dd><dd><a href="/book/6438/2647.htm">第十三章 哀恸</a></dd><dd><a href="/book/6438/2648.htm">第十四章 情舞</a></dd><dd><a href="/book/6438/2649.htm">第十五章 出征</a></dd><dd><a href="/book/6438/2650.htm">第十六章 中毒</a></dd><dd><a href="/book/6438/2651.htm">第十七章 毒计</a></dd><dd><a href="/book/6438/2652.htm">第十八章 险计</a></dd><dd><a href="/book/6438/2653.htm">第十九章 信任</a></dd><dd><a href="/book/6438/2654.htm">第二十章 死计</a></dd><dd><a href="/book/6438/2655.htm">第二十一章 偶遇</a></dd><dd><a href="/book/6438/2656.htm">第二十二章 逍遥</a></dd><dd><a href="/book/6438/2657.htm">番外 伤只影</a></dd><dd><a href="/book/6438/2658.htm">后记</a></dd></dl>
"""

# 正则表达式
pattern = r'href="(/[^"]+)"'
# 使用re.search查找匹配项
match = re.findall(pattern, alllink)
ll=[]
for elem in match:

    link='https://www.99csw.com'+elem
    ll.append(link)
print()


# 发送HTTP请求
for url in ll[:1]:
    url='https://www.kanunu8.com/book5/damoyao2/5728.html'

    response = requests.get(url)

    # 检查请求是否成功
    if response.status_code == 200:
        # 解析网页内容
        soup = BeautifulSoup(response.text, 'html.parser')
        print()


    else:
        print(f'Failed to retrieve the webpage. Status code: {response.status_code}')
