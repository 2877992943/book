import json

import requests
from bs4 import BeautifulSoup
import re

from selenium.webdriver.chrome.options import Options
import time
#from webdriver_manager.chrome import ChromeDriverManager
###https://www.kanunu8.com/book5/bubujingxin/

def safariDriver():
    from selenium import webdriver

    # 设置Safari的选项
    safari_options = webdriver.safari.options.Options()
    #safari_options.headless = True

    # 创建Safari WebDriver实例
    driver = webdriver.Safari(options=safari_options)

    # 打开一个网页
    #driver.get(url)

    # 你的Selenium代码可以继续在这里...

    # 最后，关闭浏览器
    #driver.quit()
    return driver

driver=safariDriver()
mainlink='https://www.kanunu8.com/book5/yunzhongge1/'
mainlink='https://www.kanunu8.com/book5/yunzhongge2/'
mainlink='https://www.kanunu8.com/book5/yunzhongge3/'
mainlink='https://www.kanunu8.com/book2/10875/'

mainlink1='https://www.kanunu8.com/book2/10874/'
mainlink2='https://www.kanunu8.com/book2/10754/'
mainlink3='https://www.kanunu8.com/book5/zuimeidesg/'
mainlink4='https://www.kanunu8.com/book5/nxhbqdnssguang/'
mainlink5='https://www.kanunu8.com/book5/nxhbqdnssguang2/'
alllink1="""
 <ul>
    <li><a href="6109.html">楔子</a></li>
    <li><a href="6110.html">第一章 昏倒在院子里的男人</a></li>
    <li><a href="6111.html">第二章 眉目如画，色转皎然</a></li>
    <li><a href="6112.html">第三章 青梅竹马来</a></li>
    <li><a href="6113.html">第四章 心里钻进了蚂蚁</a></li>
    <li><a href="6114.html">第五章 喜欢一个人的感觉</a></li>
    <li><a href="6115.html">第六章 你愿意做我的男朋友吗</a></li>
    <li><a href="6116.html">第七章 你还会做什么</a></li>
    <li><a href="6117.html">第八章 月圆之夜的约定</a></li>
    <li><a href="6118.html">第九章 我不怕你，我想要你</a></li>
    <li><a href="6119.html">第十章 如何打败时间</a></li>
    <li><a href="6120.html">第十一章 我在这里</a></li>
    <li><a href="6121.html">第十二章 我的男朋友</a></li>
    <li><a href="6122.html">第十三章 初雪般的第一个吻</a></li>
    <li><a href="6123.html">第十四章 你愿意嫁给我吗</a></li>
    <li><a href="6124.html">第十五章 心甘情愿被扑倒</a></li>
    <li><a href="6125.html">第十六章 你可以出卖我</a></li>
    <li><a href="6126.html">第十七章 绝对不可能放弃</a></li>
    <li><a href="6127.html">第十八章 我清楚自己的心意</a></li>
    <li><a href="6128.html">第十九章 这就是我们的选择</a></li>
    <li><a href="6129.html">结局 恒星一般的生命</a></li>
</ul>
"""

alllink2="""
<div class="mulu-list">
<ul>
    <li><a href="6085.html">第一章 命运</a></li>
    <li><a href="6086.html">第二章 爱情</a></li>
    <li><a href="6087.html">第三章 年轻的心</a></li>
    <li><a href="6088.html">第四章 冷暖之间</a></li>
    <li><a href="6089.html">第五章 希望</a></li>
    <li><a href="6090.html">第六章 无悔的青春</a></li>
    <li><a href="6091.html">第七章 美丽的梦</a></li>
    <li><a href="6092.html">第八章 错误</a></li>
    <li><a href="6093.html">第九章 成长</a></li>
    <li><a href="6094.html">第十章 光影幸福</a></li>
    <li><a href="6095.html">结局番外</a></li>
    <li><a href="6096.html">第十一章 生活</a></li>
    <li><a href="6097.html">第十二章 冬夜的烟火</a></li>
    <li><a href="6098.html">第十三章 爱恨</a></li>
    <li><a href="6099.html">第十四章 悲喜</a></li>
    <li><a href="6100.html">第十五章 意外的婚礼</a></li>
    <li><a href="6101.html">番外</a></li>
    <li><a href="6102.html">第十六章 假面</a></li>
    <li><a href="6103.html">第十七章 选择</a></li>
    <li><a href="6104.html">第十八章 破碎的梦境</a></li>
    <li><a href="6105.html">第十九章 真相</a></li>
    <li><a href="6106.html">第二十章 宽恕</a></li>
    <li><a href="6107.html">第二十一章 与你同行</a></li>
    <li><a href=""></a></li>
</ul>
</div>

"""

alllink3="""

<div class="mulu-list">
    <ul>
<li><a href="5580.html">第一章 邂逅</a></li>
<li><a href="5581.html">第二章 距离</a></li>
<li><a href="5582.html">第三章 快乐</a></li>
<li><a href="5583.html">第四章 刺痛</a></li>
<li><a href="5584.html">第五章 温暖</a></li>
<li><a href="5585.html">第六章 骄傲</a></li>
<li><a href="5586.html">第七章 秘密</a></li>
<li><a href="5587.html">第八章 勇气</a></li>
<li><a href="5588.html">第九章 飘雪</a></li>
<li><a href="5589.html">第十章 牵手</a></li>
<li><a href="5590.html">第十一章 幸福</a></li>
<li><a href="5591.html">第十二章 夜色</a></li>
<li><a href="5592.html">第十三章 谎言</a></li>
<li><a href="5593.html">第十四章 梦醒</a></li>
<li><a href="5594.html">第十五章 思念</a></li>
<li><a href="5595.html">第十六章 烟花</a></li>
<li><a href="5596.html">第十七章 不测</a></li>
<li><a href="5597.html">第十八章 相依</a></li>
<li><a href="5598.html">第十九章 往事</a></li>
<li><a href="5599.html">第二十章 不离</a></li>
<li><a href="5600.html">第二十一章 心伤</a></li>
<li><a href="5601.html">第二十二章 谜底</a></li>
<li><a href="5602.html">第二十三章 别离</a></li>
<li><a href="5603.html">番外一 记忆</a></li>
<li><a href="5604.html">番外二 缘聚</a></li>
<li><a href="5605.html">番外三 缘散</a></li>
<li><a href="5606.html">告别语 一</a></li>
<li><a href="5607.html">告别语 二</a></li>
<li><a href=""></a></li>
<li><a href=""></a></li>

 	</ul>
	</div>

"""


alllink4="""
<div class="catalog" style="height: auto !important;">
			<h1>那些回不去的年少时光</h1>
			<div class="info">
				作者：桐华		</div>

			<div class="summary" style="height: auto !important;">
				<b>内容简介：</b>
				<div class="intro">
					<p>《那些回不去的年少时光》以真挚的感情，真实的细节，讲述了一段发生在那个年代精彩扣人的青春和爱少女罗琦琦天性桀骜，从不妥协。青春期的她游走在两种截然不同的世界里：作业、考试、小团体的校园；游戏机房、歌舞厅、小混混斗殴泡妞的社会。她看着中国第一代歌舞厅开起来，第一批港台娱乐来到身边每个人的生活和思想都发生着剧变。她和伙伴们分享着甜蜜、忧伤、彷徨、迷惑在本书中，你可以看到所有你曾热爱却正在遗忘的人和事，更可以看到属于自己的青春和成长。</p>
				</div><div class="google-auto-placed" style="width: 100%; height: auto; clear: both; text-align: center;"><ins data-ad-format="auto" class="adsbygoogle adsbygoogle-noablate" data-ad-client="ca-pub-2995949807212160" data-adsbygoogle-status="done" style="display: block; margin: 10px auto; background-color: transparent; height: 0px;" data-ad-status="unfilled"><div id="aswift_1_host" style="border: none; height: 0px; width: 800px; margin: 0px; padding: 0px; position: relative; visibility: visible; background-color: transparent; display: inline-block; overflow: hidden; opacity: 0;"><iframe id="aswift_1" name="aswift_1" browsingtopics="true" style="left: 0px; position: absolute; top: 0px; border: 0px; width: 800px; height: 0px;" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" width="800" height="0" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" allow="attribution-reporting; run-ad-auction" src="https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-2995949807212160&amp;output=html&amp;h=280&amp;adk=1149590581&amp;adf=2548288913&amp;pi=t.aa~a.2291915000~rp.4&amp;w=800&amp;abgtt=6&amp;fwrn=4&amp;fwrnh=100&amp;lmt=1706336119&amp;rafmt=1&amp;to=qs&amp;pwprc=7017195960&amp;format=800x280&amp;url=https%3A%2F%2Fwww.kanunu8.com%2Fbook5%2Fnxhbqdnssguang%2F&amp;fwr=0&amp;pra=3&amp;rpe=1&amp;resp_fmts=3&amp;wgl=1&amp;fa=40&amp;uach=WyJtYWNPUyIsIjE1LjAuMCIsImFybSIsIiIsIjEzMy4wLjY5NDMuNTUiLG51bGwsMCxudWxsLCI2NCIsW1siTm90KEE6QnJhbmQiLCI5OS4wLjAuMCJdLFsiR29vZ2xlIENocm9tZSIsIjEzMy4wLjY5NDMuNTUiXSxbIkNocm9taXVtIiwiMTMzLjAuNjk0My41NSJdXSwwXQ..&amp;dt=1739768102881&amp;bpp=1&amp;bdt=44&amp;idt=55&amp;shv=r20250211&amp;mjsv=m202502110101&amp;ptt=9&amp;saldr=aa&amp;abxe=1&amp;cookie=ID%3D02c6ad9389e0cf8c%3AT%3D1735810601%3ART%3D1739767848%3AS%3DALNI_Mb86vyz8-O5V3twZMjNeXY2njopSw&amp;gpic=UID%3D00000fd0f4357227%3AT%3D1735810601%3ART%3D1739767848%3AS%3DALNI_MaJZb8eEV2XE372oJ1shHE7NWOfLQ&amp;eo_id_str=ID%3Db56f36fbf7bb415b%3AT%3D1735810601%3ART%3D1739767848%3AS%3DAA-AfjbuSr31RirP8HgFtqfVdvos&amp;prev_fmts=0x0&amp;nras=2&amp;correlator=6475779380714&amp;frm=20&amp;pv=1&amp;u_tz=480&amp;u_his=1&amp;u_h=982&amp;u_w=1512&amp;u_ah=890&amp;u_aw=1512&amp;u_cd=30&amp;u_sd=2&amp;dmc=8&amp;adx=349&amp;ady=318&amp;biw=1497&amp;bih=738&amp;scr_x=0&amp;scr_y=0&amp;eid=31090351%2C95352069%2C31088249%2C95347433%2C95350016&amp;oid=2&amp;pvsid=1191411444622448&amp;tmod=1390327607&amp;uas=0&amp;nvt=1&amp;ref=https%3A%2F%2Fwww.kanunu8.com%2Ffiles%2Fwriter%2F1415.html&amp;fc=1920&amp;brdim=0%2C0%2C0%2C0%2C1512%2C38%2C0%2C0%2C1512%2C738&amp;vis=2&amp;rsz=%7C%7Cs%7C&amp;abl=NS&amp;fu=128&amp;bc=31&amp;bz=0&amp;td=1&amp;tdf=2&amp;psd=W251bGwsbnVsbCxudWxsLDFd&amp;nt=1&amp;ifi=2&amp;uci=a!2&amp;fsb=1&amp;dtd=56" data-google-container-id="a!2" tabindex="0" title="Advertisement" aria-label="Advertisement" data-google-query-id="CIicm571yYsDFaWH6QUdTUkc7w" data-load-complete="true"></iframe></div></ins></div>
			</div>
			<div class="author">
				 &nbsp;&nbsp;&nbsp;&nbsp;→  <a href="/files/writer/1415.html">桐华作品集</a>
			</div>
    <div class="mulu-title"><h2>第一部</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="3335.html">Chapter 1 满身风雨我从海上来</a></li>
<li><a href="3336.html">Chapter 2 回忆的开始</a></li>
<li><a href="3337.html">Chapter 3 我遇见了他</a></li>
<li><a href="3338.html">Chapter 4 我变成了一个四眼熊猫</a></li>
<li><a href="3339.html">Chapter 5 人生第一次挂彩</a></li>
<li><a href="3340.html">Chapter 6 情窦初开</a></li>
<li><a href="3341.html">Chapter 7 命运被扭转</a></li>
<li><a href="3342.html">Chapter 8 外公的去世</a></li>
<li><a href="3343.html">Chapter 9 还未恋爱，就已失恋</a></li>
<li><a href="3344.html">Chapter 10 数学竞赛</a></li>

 	</ul>
	</div>

    <div class="mulu-title"><h2>第二部</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="3346.html">Chapter 1 第四</a></li>
<li><a href="3347.html">Chapter 2 我的友谊</a></li>
<li><a href="3348.html">Chapter 3 噩梦重现</a></li>
<li><a href="3349.html">Chapter 4 极品是如何练成的</a></li>
<li><a href="3350.html">Chapter 5 文艺汇演</a></li>
<li><a href="3351.html">Chapter 6 大龄留级生</a></li>
<li><a href="3352.html">Chapter 7 演讲比赛</a></li>
<li><a href="3353.html">Chapter 8 王征的情人</a></li>
<li><a href="3354.html">Chapter 9 伤心也是一件很复杂的事情</a></li>
<li><a href="3355.html">Chapter 10 有悔恨的青春</a></li>
<li><a href="3356.html">Chapter 11 棋盘的第一个颤抖</a></li>
<li><a href="3357.html">Chapter 12 我的第一支舞</a></li>
<li><a href="3358.html">Chapter 13 快乐的暑假</a></li>
<li><a href="3359.html">Chapter 14 摔伤的手</a></li>
<li><a href="3360.html">Chapter 15 关荷的秘密</a></li>
<li><a href="3361.html">Chapter 16 我只愿这是一场梦魇</a></li>
<li><a href="3362.html">Chapter 17 情一往而深</a></li>
<li><a href="3363.html">Chapter 18 永远的回忆</a></li>
<li><a href="3364.html">Chapter 19 被折断的翅膀</a></li>

 	</ul>
	</div>

    <div class="mulu-title"><h2>第三部</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="3366.html">前言：被沉默埋葬的过去</a></li>
<li><a href="3367.html">Chapter 1 高一的开始</a></li>
<li><a href="3368.html">Chapter 2 回避冲突</a></li>
<li><a href="3369.html">Chapter 3 再次成为名人</a></li>
<li><a href="3370.html">Chapter 4 简单生活</a></li>
<li><a href="3371.html">Chapter 5 第一件大事</a></li>
<li><a href="3372.html">Chapter 6 少男少女的心思</a></li>
<li><a href="3373.html">Chapter 7 尴尬快乐的北京</a></li>
<li><a href="3374.html">Chapter 8 青岛的最后一天</a></li>
<li><a href="3375.html">Chapter 9 想要什么样的人生风景</a></li>
<li><a href="3376.html">Chapter 10 爱情是什么</a></li>
<li><a href="3377.html">Chapter 11 高二开始了</a></li>
<li><a href="3378.html">Chapter 12 年级第一</a></li>
<li><a href="3379.html">Chapter 13 关于爱情的猜忌</a></li>
<li><a href="3380.html">Chapter 14 目标：省状元</a></li>
<li><a href="3381.html">Chapter 15 模拟考试</a></li>
<li><a href="3382.html">Chapter 16 永远记住的初吻</a></li>
<li><a href="3383.html">Chapter 17 金榜题名时</a></li>
<li><a href="3384.html">Chapter 18 似水流年</a></li>
<li><a href="3385.html">尾声：宽恕的美丽</a></li>
<li><a href="3386.html">番外1：张骏</a></li>
<li><a href="3387.html">番外2：许小波</a></li>
<li><a href="3388.html">番外3：许小波</a></li>

 	</ul>
	</div>

<div class="mulu-title"><h2 class="">看过此书的人还喜欢</h2></div>
<div class="common-list1 common-list2">
<a href="/book2/10914/"><b>1</b>《知否？知否？应是绿肥红瘦》<span class="common-ver-line">作者：关心则乱</span></a>
<a href="/book2/11024/"><b>2</b>《很想很想你》<span class="common-ver-line">作者：墨宝非宝</span></a>
<a href="/book5/shunvgonglue/"><b>4</b>《庶女攻略(锦心似玉)》<span class="common-ver-line">作者：吱吱</span></a>
<a href="/book5/fanhua/"><b>2</b>《繁花》<span class="common-ver-line">作者：金宇澄</span></a>
<a href="/book2/10966/"><b>2</b>《大江东去》<span class="common-ver-line">作者：阿耐</span></a>
<a class="load-more" href="/genres.html">查看图书全部分类</a>
	</div>
	</div>

"""

alllink5="""

<div class="catalog" style="height: auto !important;">
			<h1>那些回不去的年少时光：终场</h1>
			<div class="info">
				作者：桐华		</div>

			<div class="summary" style="height: auto !important;">
				<b>内容简介：</b>
				<div class="intro">
					<p>故事虽落幕，青春不终场！经过孤独的小学时光，混乱的初中生涯，罗琦琦来到了高中。和所有走过那段岁月的人一样，面对高考的折磨，罗琦琦虽然不情愿，却也无法做到不在乎，学习并不好的她，性格倔强不服输的她，究竟如何才能完成完美转身？爱情，也是挑战她的另一大命题。她和他又走到了一起，他对她似乎已经倾心，只是她们身后还有一个他。她该如何面对，又该如何选择？青春期的友情叫人唏嘘和心碎，青春期爱情叫人甜蜜又纠结，世纪末的社会如此复杂，叫人难以理清头绪。罗琦琦和她的同学们，就这样孤独而热闹地，混沌而逐渐清醒地成长起来了……</p>
				</div><div class="google-auto-placed" style="width: 100%; height: auto; clear: both; text-align: center;"><ins data-ad-format="auto" class="adsbygoogle adsbygoogle-noablate" data-ad-client="ca-pub-2995949807212160" data-adsbygoogle-status="done" style="display: block; margin: 10px auto; background-color: transparent; height: 280px;" data-ad-status="unfilled"><div id="aswift_1_host" style="border: none; height: 280px; width: 800px; margin: 0px; padding: 0px; position: relative; visibility: visible; background-color: transparent; display: inline-block; overflow: visible;"><iframe id="aswift_1" name="aswift_1" browsingtopics="true" style="left:0;position:absolute;top:0;border:0;width:800px;height:280px;" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" width="800" height="280" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" allow="attribution-reporting; run-ad-auction" src="https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-2995949807212160&amp;output=html&amp;h=280&amp;adk=1149590581&amp;adf=2548288913&amp;pi=t.aa~a.2291915000~rp.4&amp;w=800&amp;abgtt=6&amp;fwrn=4&amp;fwrnh=100&amp;lmt=1706537677&amp;rafmt=1&amp;to=qs&amp;pwprc=7017195960&amp;format=800x280&amp;url=https%3A%2F%2Fwww.kanunu8.com%2Fbook5%2Fnxhbqdnssguang2%2F&amp;fwr=0&amp;pra=3&amp;rpe=1&amp;resp_fmts=3&amp;wgl=1&amp;fa=40&amp;uach=WyJtYWNPUyIsIjE1LjAuMCIsImFybSIsIiIsIjEzMy4wLjY5NDMuNTUiLG51bGwsMCxudWxsLCI2NCIsW1siTm90KEE6QnJhbmQiLCI5OS4wLjAuMCJdLFsiR29vZ2xlIENocm9tZSIsIjEzMy4wLjY5NDMuNTUiXSxbIkNocm9taXVtIiwiMTMzLjAuNjk0My41NSJdXSwwXQ..&amp;dt=1739768241657&amp;bpp=1&amp;bdt=42&amp;idt=18&amp;shv=r20250211&amp;mjsv=m202502110101&amp;ptt=9&amp;saldr=aa&amp;abxe=1&amp;cookie=ID%3D02c6ad9389e0cf8c%3AT%3D1735810601%3ART%3D1739767848%3AS%3DALNI_Mb86vyz8-O5V3twZMjNeXY2njopSw&amp;gpic=UID%3D00000fd0f4357227%3AT%3D1735810601%3ART%3D1739767848%3AS%3DALNI_MaJZb8eEV2XE372oJ1shHE7NWOfLQ&amp;eo_id_str=ID%3Db56f36fbf7bb415b%3AT%3D1735810601%3ART%3D1739767848%3AS%3DAA-AfjbuSr31RirP8HgFtqfVdvos&amp;prev_fmts=0x0&amp;nras=2&amp;correlator=3878677951806&amp;frm=20&amp;pv=1&amp;u_tz=480&amp;u_his=1&amp;u_h=982&amp;u_w=1512&amp;u_ah=890&amp;u_aw=1512&amp;u_cd=30&amp;u_sd=2&amp;dmc=8&amp;adx=349&amp;ady=318&amp;biw=1497&amp;bih=738&amp;scr_x=0&amp;scr_y=0&amp;eid=31090351%2C95332590%2C95350441%2C95352068%2C95347433%2C95350016%2C31061690&amp;oid=2&amp;pvsid=25488779701429&amp;tmod=1390327607&amp;uas=0&amp;nvt=1&amp;ref=https%3A%2F%2Fwww.kanunu8.com%2Ffiles%2Fwriter%2F1415.html&amp;fc=1920&amp;brdim=0%2C38%2C0%2C38%2C1512%2C38%2C1512%2C877%2C1512%2C738&amp;vis=1&amp;rsz=%7C%7Cs%7C&amp;abl=NS&amp;fu=128&amp;bc=31&amp;bz=1&amp;td=1&amp;tdf=2&amp;psd=W251bGwsbnVsbCxudWxsLDFd&amp;nt=1&amp;ifi=2&amp;uci=a!2&amp;fsb=1&amp;dtd=19" data-google-container-id="a!2" tabindex="0" title="Advertisement" aria-label="Advertisement" data-google-query-id="CJvlruD1yYsDFeBXDwIdE4UNOQ" data-load-complete="true"></iframe></div></ins></div>
			</div>
			<div class="author">
				 &nbsp;&nbsp;&nbsp;&nbsp;→  <a href="/files/writer/1415.html">桐华作品集</a>
			</div>
    <div class="mulu-title"><h2>第一章 全新简单生活</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="6152.html">前言：被沉默埋葬的过去</a></li>
<li><a href="6153.html">1、高一的开始</a></li>
<li><a href="6154.html">2、回避冲突</a></li>
<li><a href="6155.html">3、再次成为名人</a></li>
 	</ul>
	</div>

    <div class="mulu-title"><h2>第二章 那些鲜艳色彩</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="6157.html">1、简单生活</a></li>
<li><a href="6158.html">2、第一件大事</a></li>
<li><a href="6159.html">3、少男少女的心思</a></li>
 	</ul>
	</div>
    <div class="mulu-title"><h2>第三章 回看人生风景</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="6161.html">1、尴尬快乐的北京</a></li>
<li><a href="6179.html">2、青岛的最后一天</a></li>
<li><a href="6162.html">3、想要什么样的人生风景</a></li>
<li><a href="6163.html">4、爱情是什么</a></li>
 	</ul>
	</div>

    <div class="mulu-title"><h2>第四章 青春花开两枝</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="6165.html">1、高二开始了</a></li>
<li><a href="6166.html">2、年级第一</a></li>
<li><a href="6167.html">3、关于爱情的猜忌</a></li>
 	</ul>
	</div>

    <div class="mulu-title"><h2>第五章 两个人的对视</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="6169.html">1、目标：省状元</a></li>
<li><a href="6170.html">2、模拟考试</a></li>
 	</ul>
	</div>

    <div class="mulu-title"><h2>第六章 那盛大的告别</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="6172.html">1、永远记住的初吻</a></li>
<li><a href="6180.html">2、金榜题名时</a></li>
<li><a href="6173.html">3、似水流年</a></li>
<li><a href="6174.html">尾声：宽恕的美丽</a></li>
 	</ul>
	</div>

    <div class="mulu-title"><h2>第七章 番外之两个人</h2></div>
    <div class="mulu-list">
    <ul>
<li><a href="6176.html">番外1：张骏</a></li>
<li><a href="6177.html">番外2：许小波</a></li>
<li><a href="6178.html">番外3：许小波</a></li>

 	</ul>
	</div>
		
<div class="mulu-title"><h2 class="">看过此书的人还喜欢</h2></div>
<div class="common-list1 common-list2">
<a href="/book2/10914/"><b>1</b>《知否？知否？应是绿肥红瘦》<span class="common-ver-line">作者：关心则乱</span></a>
<a href="/book2/11024/"><b>2</b>《很想很想你》<span class="common-ver-line">作者：墨宝非宝</span></a>
<a href="/book5/shunvgonglue/"><b>4</b>《庶女攻略(锦心似玉)》<span class="common-ver-line">作者：吱吱</span></a>
<a href="/book5/fanhua/"><b>2</b>《繁花》<span class="common-ver-line">作者：金宇澄</span></a>
<a href="/book2/10966/"><b>2</b>《大江东去》<span class="common-ver-line">作者：阿耐</span></a>
<a class="load-more" href="/genres.html">查看图书全部分类</a>
	</div>
	</div>

"""
jsonpath1='./html_NapianXingKong.json'
jsonpath2='./html_banNuanShiGuang.json'
jsonpath3='./html_zuimeishiguang.json'
jsonpath4='./html_huiBuquNianshaoShiguang.json'
jsonpath5='./html_huiBuquNianshaoShiguang2.json'



# 正则表达式
#pattern = r'href="(/[^"]+)"'
pattern=r'href="(\d+\.html)"'
# 使用re.search查找匹配项


def main(alllink,jsonpath,mainlink):
    match = re.findall(pattern, alllink)
    ll=[]
    for elem in match:
        link=mainlink+elem
        ll.append(link)
    print(ll)


    url=ll[0]
    rst=[]
    wr=open(jsonpath,'w')
    for url in ll:
        print(66,url)
        # 打开网页
        driver.get(url)
        time.sleep(4)
        # 获取网页源代码
        page_source = driver.page_source

        wr.write(json.dumps([page_source],ensure_ascii=False)+'\n')
        #break


        # 打印源代码
        print(page_source)
        time.sleep(6)





main(alllink1,jsonpath1,mainlink1)
main(alllink2,jsonpath2,mainlink2)
main(alllink3,jsonpath3,mainlink3)
main(alllink4,jsonpath4,mainlink4)
main(alllink5,jsonpath5,mainlink5)
driver.quit()

