import json

import requests
from bs4 import BeautifulSoup
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

###https://www.kanunu8.com/book5/bubujingxin/




alllink="""
<div class="mulu-list">
    <ul>
<li><a href="5728.html">第一章：绑架</a></li>
<li><a href="5729.html">第二章：情愫</a></li>
<li><a href="5730.html">第三章：鸽魂</a></li>
<li><a href="5731.html">第四章：失身</a></li>
<li><a href="5732.html">第五章：初吻</a></li>
<li><a href="5733.html">第六章：逃命</a></li>
<li><a href="5734.html">第七章：蹴鞠</a></li>
<li><a href="5735.html">第八章：灿笑</a></li>
<li><a href="5736.html">第九章：情乱</a></li>
<li><a href="5737.html">第十章：怒吻</a></li>
<li><a href="5738.html">第十一章：吵架</a></li>
<li><a href="5739.html">第十二章：生病</a></li>
<li><a href="5740.html">第十三章：哀恸</a></li>
<li><a href="5741.html">第十四章：情舞</a></li>
<li><a href="5742.html">第十五章：出征</a></li>
<li><a href="5743.html">第十六章：中毒</a></li>
<li><a href="5744.html">第十七章：毒计</a></li>
<li><a href="5745.html">第十八章：险计</a></li>
<li><a href="5746.html">第十九章：信任</a></li>
<li><a href="5747.html">第二十章：死计</a></li>
<li><a href="5748.html">第二十一章：偶遇</a></li>
<li><a href="5749.html">第二十二章：逍遥</a></li>
<li><a href="5750.html">第二十三章：伤只影</a></li>
<li><a href="5751.html">最后的告别语</a></li>

 	</ul>
	</div>
"""

# 正则表达式
pattern = r'href="(/[^"]+)"'
pattern=r'href="(\d+\.html)"'
# 使用re.search查找匹配项
match = re.findall(pattern, alllink)
ll=[]
for elem in match:

    link='https://www.kanunu8.com/book5/damoyao2/'+elem
    ll.append(link)
print()

# 指定ChromeDriver的路径
chromedriver_path = 'path/to/chromedriver'

# 初始化webdriver
options = webdriver.ChromeOptions()
# 如果不希望浏览器界面出现，可以添加以下选项
#options.add_argument('--headless')

# 创建一个Chrome浏览器实例
driver = webdriver.Chrome(#executable_path=chromedriver_path,
                          options=options)
# 发送HTTP请求
url=ll[0]
rst=[]
wr=open('./html_damoyao2.json','w')
for url in ll:
    # 打开网页
    driver.get(url)
    time.sleep(4)
    # 获取网页源代码
    page_source = driver.page_source

    wr.write(json.dumps([page_source],ensure_ascii=False)+'\n')
    #break


    # 打印源代码
    print(page_source)
    time.sleep(6)
driver.quit()

#
# try:
#     # 等待弹出按钮出现，设置最长等待时间
#     popup_button = WebDriverWait(driver, 10).until(
#         EC.element_to_be_clickable((By.ID, 'popup_button_id'))  # 使用合适的定位器替换'popup_button_id'
#     )
#
#     # 点击弹出按钮
#     popup_button.click()
#
#     # 获取网页源代码
#     page_source = driver.page_source
#
#     # 打印源代码
#     print(page_source)
#
# finally:
#     # 关闭浏览器
#     driver.quit()



